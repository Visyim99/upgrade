<?php


class HeavyEquip extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'webhvyequip';

	protected $primaryKey = 'HvyEquipID';
        
        public $timestamps = false;

}