<?php


class AllPersonalProperty extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'webtable';

	protected $primaryKey = 'StateID';
        
        public $timestamps = false;

}